# Micro > 2022-12-22 6:02pm
https://universe.roboflow.com/microplastics-sihae/micro-v7xhj

Provided by a Roboflow user
License: CC BY 4.0

